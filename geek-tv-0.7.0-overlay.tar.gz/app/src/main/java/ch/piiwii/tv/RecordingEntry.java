package ch.piiwii.tv;

import org.json.JSONException;
import org.json.JSONObject;

public final class RecordingEntry {
    public static final String STATE_RECORDING = "recording";
    public static final String STATE_COMPLETE = "complete";
    public static final String STATE_FAILED = "failed";
    public static final String STATE_INTERRUPTED = "interrupted";

    public final String id;
    public final String channelId;
    public final String channelName;
    public final String title;
    public final long startMs;
    public final long expectedEndMs;
    public final long endMs;
    public final String state;
    public final String directoryPath;
    public final String playlistPath;
    public final long bytes;
    public final String error;
    public final boolean protectedItem;
    public final long playbackPositionMs;

    public RecordingEntry(String id, String channelId, String channelName, String title,
                          long startMs, long expectedEndMs, long endMs, String state,
                          String directoryPath, String playlistPath, long bytes,
                          String error, boolean protectedItem, long playbackPositionMs) {
        this.id = id;
        this.channelId = channelId;
        this.channelName = channelName;
        this.title = title;
        this.startMs = startMs;
        this.expectedEndMs = expectedEndMs;
        this.endMs = endMs;
        this.state = state;
        this.directoryPath = directoryPath;
        this.playlistPath = playlistPath;
        this.bytes = bytes;
        this.error = error;
        this.protectedItem = protectedItem;
        this.playbackPositionMs = playbackPositionMs;
    }

    public RecordingEntry withState(String newState, long newEndMs, long newBytes, String newError) {
        return new RecordingEntry(id, channelId, channelName, title, startMs, expectedEndMs,
                newEndMs, newState, directoryPath, playlistPath, newBytes, newError,
                protectedItem, playbackPositionMs);
    }

    public RecordingEntry withProgress(long newBytes) {
        return new RecordingEntry(id, channelId, channelName, title, startMs, expectedEndMs,
                endMs, state, directoryPath, playlistPath, newBytes, error,
                protectedItem, playbackPositionMs);
    }

    public RecordingEntry withPlaybackPosition(long positionMs) {
        return new RecordingEntry(id, channelId, channelName, title, startMs, expectedEndMs,
                endMs, state, directoryPath, playlistPath, bytes, error,
                protectedItem, positionMs);
    }

    public RecordingEntry withProtected(boolean value) {
        return new RecordingEntry(id, channelId, channelName, title, startMs, expectedEndMs,
                endMs, state, directoryPath, playlistPath, bytes, error,
                value, playbackPositionMs);
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("channel_id", channelId);
        o.put("channel_name", channelName);
        o.put("title", title);
        o.put("start_ms", startMs);
        o.put("expected_end_ms", expectedEndMs);
        o.put("end_ms", endMs);
        o.put("state", state);
        o.put("directory_path", directoryPath);
        o.put("playlist_path", playlistPath);
        o.put("bytes", bytes);
        o.put("error", error);
        o.put("protected", protectedItem);
        o.put("playback_position_ms", playbackPositionMs);
        return o;
    }

    public static RecordingEntry fromJson(JSONObject o) {
        return new RecordingEntry(
                o.optString("id"),
                o.optString("channel_id"),
                o.optString("channel_name"),
                o.optString("title"),
                o.optLong("start_ms"),
                o.optLong("expected_end_ms"),
                o.optLong("end_ms"),
                o.optString("state", STATE_FAILED),
                o.optString("directory_path"),
                o.optString("playlist_path"),
                o.optLong("bytes"),
                o.optString("error"),
                o.optBoolean("protected", false),
                o.optLong("playback_position_ms", )rdingEnt-  o.oyback_p