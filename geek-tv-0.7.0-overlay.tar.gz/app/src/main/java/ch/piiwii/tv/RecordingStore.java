package ch.piiwii.tv;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class RecordingStore {
    private static final String PREFS = "geek_tv_recordings";
    private static final String KEY = "items";
    private final SharedPreferences prefs;

    public RecordingStore(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public synchronized List<RecordingEntry> list() {
        ArrayList<RecordingEntry> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs.getString(KEY, "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o != null) out.add(RecordingEntry.fromJson(o));
            }
        } catch (Exception ignored) { }
        out.sort(Comparator.comparingLong((RecordingEntry r) -> r.startMs).reversed());
        return out;
    }

    public synchronized RecordingEntry get(String id) {
        for (RecordingEntry r : list()) if (r.id.equals(id)) return r;
        return null;
    }

    public synchronized RecordingEntry active() {
        for (RecordingEntry r : list()) if (RecordingEntry.STATE_RECORDING.equals(r.state)) return r;
        return null;
    }

    public synchronized void upsert(RecordingEntry entry) {
        List<RecordingEntry> items = list();
        boolean found = false;
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).id.equals(entry.id)) {
                items.set(i, entry);
                found = true;
                break;
            }
        }
        if (!found) items.add(entry);
        save(items);
    }

    public synchronized void remove(String id, boolean deleteFiles) {
        List<RecordingEntry> items = list();
        RecordingEntry target = null;
        for (RecordingEntry r : items) if (r.id.equals(id)) target = r;
        items.removeIf(r -> r.id.equals(id));
        save(items);
        if (deleteFiles && target != null && !target.directoryPath.isEmpty()) deleteRecursive(new File(target.directoryPath));
    }

    public synchronized void setPlaybackPosition(String id, long positionMs) {
        RecordingEntry r = get(id);
        if (r != null) upsert(r.withPlaybackPosition(positionMs));
    }

    public synchronized void setProtected(String id, boolean value) {
        RecordingEntry r = get(id);
        if (r != null) upsert(r.withProtected(value));
    }

    private void save(List<RecordingEntry> items) {
        JSONArray a = new JSONArray();
        for (RecordingEntry r : items) {
            try { a.put(r.toJson()); } catch (Exception ignored) { }
        }
        prefs.edit().putString(KEY, a.toString()).apply();
    }

    private static void deleteRecursive(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] children = f.listFiles();
            if (children != null) for (File c : children) deleteRecursive(c);
        }
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }
}
