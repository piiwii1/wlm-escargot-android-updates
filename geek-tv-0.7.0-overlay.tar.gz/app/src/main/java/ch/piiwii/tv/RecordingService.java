package ch.piiwii.tv;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import java.io.File;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public final class RecordingService extends Service {
    public static final String ACTION_START = "ch.piiwii.tv.action.START_RECORDING";
    public static final String ACTION_STOP = "ch.piiwii.tv.action.STOP_RECORDING";
    public static final String EXTRA_ID = "recording_id";
    public static final String EXTRA_CHANNEL_ID = "channel_id";
    public static final String EXTRA_CHANNEL_NAME = "channel_name";
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_URL = "url";
    public static final String EXTRA_USER_AGENT = "user_agent";
    public static final String EXTRA_STOP_AT = "stop_at";

    private static final String CHANNEL_ID = "geek_tv_recording";
    private static final int NOTIFICATION_ID = 7201;

    private final AtomicBoolean stopRequested = new AtomicBoolean(false);
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private RecordingStore store;
    private String recordingId;
    private String channelName;
    private String title;
    private long startedMs;
    private PowerManager.WakeLock wakeLock;
    private WifiManager.WifiLock wifiLock;

    @Override
    public void onCreate() {
        super.onCreate();
        store = new RecordingStore(this);
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();
        if (ACTION_STOP.equals(action)) {
            String target = intent.getStringExtra(EXTRA_ID);
            if (target == null || target.equals(recordingId)) stopRequested.set(true);
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(action)) return START_NOT_STICKY;
        if (recordingId != null) return START_NOT_STICKY;

        recordingId = intent.getStringExtra(EXTRA_ID);
        String channelId = intent.getStringExtra(EXTRA_CHANNEL_ID);
        channelName = intent.getStringExtra(EXTRA_CHANNEL_NAME);
        title = intent.getStringExtra(EXTRA_TITLE);
        String url = intent.getStringExtra(EXTRA_URL);
        String userAgent = intent.getStringExtra(EXTRA_USER_AGENT);
        long stopAt = intent.getLongExtra(EXTRA_STOP_AT, 0L);
        if (recordingId == null || channelId == null || channelName == null || title == null || url == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        File base = getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES);
        if (base == null) base = getFilesDir();
        File root = new File(base, "GeekTV/recordings");
        File dir = new File(root, recordingId);
        File playlist = new File(dir, "recording.m3u8");
        startedMs = System.currentTimeMillis();
        RecordingEntry entry = new RecordingEntry(
                recordingId, channelId, channelName, title, startedMs, stopAt, 0L,
                RecordingEntry.STATE_RECORDING, dir.getAbsolutePath(), playlist.getAbsolutePath(),
                0L, "", false, 0L
        );
        store.upsert(entry);

        startAsForeground(buildNotification(0L, 0L, false));
        acquireLocks();
        executor.execute(() -> {
            HlsRecorder recorder = new HlsRecorder(url, userAgent, dir, stopAt, stopRequested, new HlsRecorder.Listener() {
                private long lastNotification = 0;
                @Override public void onStarted(String mediaUrl) {
                    updateEntryProgress(0L);
                }
                @Override public void onProgress(long elapsedMs, long bytes) {
                    updateEntryProgress(bytes);
                    long now = System.currentTimeMillis();
                    if (now - lastNotification >= 5000L) {
                        notifyProgress(elapsedMs, bytes, false);
                        lastNotification = now;
                    }
                }
                @Override public void onFinished(long bytes) {
                    RecordingEntry current = store.get(recordingId);
                    if (current != null) {
                        String state = bytes > 0 ? RecordingEntry.STATE_COMPLETE : RecordingEntry.STATE_INTERRUPTED;
                        store.upsert(current.withState(state, System.currentTimeMillis(), bytes, ""));
                    }
                    notifyProgress(System.currentTimeMillis() - startedMs, bytes, true);
                    finishService();
                }
                @Override public void onError(String message, long bytes) {
                    RecordingEntry current = store.get(recordingId);
                    if (current != null) {
                        String state = bytes > 0 ? RecordingEntry.STATE_INTERRUPTED : RecordingEntry.STATE_FAILED;
                        store.upsert(current.withState(state, System.currentTimeMillis(), bytes, message));
                    }
                    notifyError(message);
                    finishService();
                }
            });
            recorder.run();
        });
        return START_NOT_STICKY;
    }

    private void updateEntryProgress(long bytes) {
        RecordingEntry current = store.get(recordingId);
        if (current != null) store.upsert(current.withProgress(bytes));
    }

    private void startAsForeground(Notification notification) {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private void notifyProgress(long elapsedMs, long bytes, boolean complete) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.notify(NOTIFICATION_ID, buildNotification(elapsedMs, bytes, complete));
    }

    private Notification buildNotification(long elapsedMs, long bytes, boolean complete) {
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stop = new Intent(this, RecordingService.class);
        stop.setAction(ACTION_STOP);
        stop.putExtra(EXTRA_ID, recordingId);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        String content = channelName + " — " + title;
        if (!complete) content += " · " + formatDuration(elapsedMs) + " · " + formatSize(bytes);
        else content += " · terminé · " + formatSize(bytes);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.presence_video_online)
                .setContentTitle(complete ? "Geek TV — Enregistrement terminé" : "Geek TV — Enregistrement")
                .setContentText(content)
                .setStyle(new Notification.BigTextStyle().bigText(content))
                .setOngoing(!complete)
                .setOnlyAlertOnce(true)
                .setContentIntent(openPi)
                .setCategory(Notification.CATEGORY_PROGRESS)
                .setVisibility(Notification.VISIBILITY_PUBLIC);
        if (!complete) b.addAction(new Notification.Action.Builder(null, "Arrêter", stopPi).build());
        return b.build();
    }

    private void notifyError(String message) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        b.setSmallIcon(android.R.drawable.stat_notify_error)
                .setContentTitle("Geek TV — Enregistrement interrompu")
                .setContentText(message)
                .setStyle(new Notification.BigTextStyle().bigText(channelName + " — " + title + "\n" + message))
                .setAutoCancel(true)
                .setContentIntent(pi);
        nm.notify(NOTIFICATION_ID, b.build());
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel c = new NotificationChannel(CHANNEL_ID, "Enregistrements Geek TV", NotificationManager.IMPORTANCE_LOW);
        c.setDescription("État des enregistrements TV en cours");
        nm.createNotificationChannel(c);
    }

    private void acquireLocks() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GeekTV:Recording");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire(6L * 60L * 60L * 1000L);
        } catch (Exception ignored) { }
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "GeekTV:RecordingWifi");
            wifiLock.setReferenceCounted(false);
            wifiLock.acquire();
        } catch (Exception ignored) { }
    }

    private void releaseLocks() {
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (Exception ignored) { }
        try { if (wifiLock != null && wifiLock.isHeld()) wifiLock.release(); } catch (Exception ignored) { }
    }

    private void finishService() {
        releaseLocks();
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_DETACH);
        else stopForeground(false);
        recordingId = null;
        stopSelf();
    }

    @Override
    public void onDestroy() {
        stopRequested.set(true);
        releaseLocks();
        executor.shutdownNow();
        super.onDestroy();
    }

    @Override
    public void onTimeout(int startId, int fgsType) {
        stopRequested.set(true);
        RecordingEntry current = store == null || recordingId == null ? null : store.get(recordingId);
        if (current != null) {
            store.upsert(current.withState(RecordingEntry.STATE_INTERRUPTED, System.currentTimeMillis(), current.bytes,
                    "Limite Android du service d’enregistrement atteinte"));
        }
        finishService();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private static String formatDuration(long ms) {
        long total = Math.max(0, ms / 1000L);
        long h = total / 3600L;
        long m = (total % 3600L) / 60L;
        long s = total % 60L;
        return h > 0 ? String.format(Locale.FRANCE, "%d:%02d:%02d", h, m, s) : String.format(Locale.FRANCE, "%02d:%02d", m, s);
    }

    private static String formatSize(long bytes) {
        if (bytes < 1024L * 1024L) return String.format(Locale.FRANCE, "%.1f Mo", bytes / 1024.0 / 1024.0);
        if (bytes < 1024L * 1024L * 1024L) return String.format(Locale.FRANCE, "%.0f Mo", bytes / 1024.0 / 1024.0);
        return String.format(Locale.FRANCE, "%.2f Go", bytes / 1024.0 / 1024.0 / 1024.0);
    }
}
