package ch.piiwii.tv;

import android.graphics.Color;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class ChannelCatalog {
    private static final int GOOD = Color.rgb(97, 216, 145);
    private static final int WARN = Color.rgb(255, 194, 92);
    private static final int MUTED = Color.rgb(166, 185, 206);
    private static final String UA = "GeekTV/0.7 Android Media3";

    private ChannelCatalog() {}

    public static List<Channel> defaults() {
        List<Channel> out = new ArrayList<>();
        out.add(ch("rts1", "RTS 1", "RTS1", "Suisse", "rts1hd", "rts1hd.png", "RTS1.ch", "✓ image + son · audio FR prioritaire", GOOD));
        out.add(ch("rts2", "RTS 2", "RTS2", "Suisse", "rts2hd", "rts2hd.png", "RTS2.ch", "Son OK · vidéo à diagnostiquer", WARN));
        out.add(ch("canal9", "Canal9", "C9", "Suisse", "canal9", "canal9.png", "canal9.ch", "✓ image + son testés", GOOD));
        out.add(ch("tf1", "TF1 CH", "TF1", "France", "tf1hd", "tf1hd.png", "TF1.fr", "À tester", MUTED));
        out.add(ch("france2", "France 2", "F2", "France", "france2hd", "france2hd.png", "France2.fr", "À tester", MUTED));
        out.add(ch("france3", "France 3", "F3", "France", "france3hd", "france3hd.png", "France3.fr", "À tester", MUTED));
        out.add(ch("france5", "France 5", "F5", "France", "france5hd", "france5hd.png", "France5.fr", "À tester", MUTED));
        out.add(ch("m6", "M6 CH", "M6", "France", "m6hd", "m6hd.png", "M6.fr", "Son OK · vidéo à diagnostiquer", WARN));
        out.add(ch("tmc", "TMC", "TMC", "France", "tmc", "tmc.png", "TMC.fr", "À tester", MUTED));
        out.add(ch("w9", "W9", "W9", "France", "w9", "w9.png", "W9.fr", "À tester", MUTED));
        out.add(ch("tfx", "TFX", "TFX", "France", "nt1", "nt1.png", "TFX.fr", "À tester", MUTED));
        out.add(ch("6ter", "6ter CH", "6ter", "France", "6ter", "6ter.png", "6ter.fr", "À tester", MUTED));
        out.add(ch("rmcstory", "RMC Story", "RMC S", "France", "numero23", "numero23.png", "RMCStory.fr", "À tester", MUTED));
        out.add(ch("rmcdecouverte", "RMC Découverte", "RMC D", "France", "rmcdecouverte", "rmcdecouverte.png", "RMCDecouverte.fr", "À tester", MUTED));
        out.add(ch("arte", "Arte", "ARTE", "France", "artehd", "artehd.png", "ARTE.fr", "À tester", MUTED));
        out.add(ch("bfmtv", "BFM TV", "BFM", "France", "bfmtv", "bfmtv.png", "BFMTV.fr", "À tester", MUTED));
        out.add(ch("cnews", "CNEWS", "CNEWS", "France", "itele", "itele.png", "CNEWS.fr", "À tester", MUTED));
        out.add(ch("lci", "LCI", "LCI", "France", "lci", "lci.png", "LCI.fr", "À tester", MUTED));
        return out;
    }

    private static Channel ch(String id, String name, String shortName, String group, String streamId, String logoFile,
                              String epgId, String note, int noteColor) {
        String url = "https://viamotionhsi.netplus.ch/live/eds/" + streamId + "/browser-HLS8/" + streamId + ".m3u8";
        ChannelSource primary = new ChannelSource("netplus-main", url, "https", "HLS", 100, UA, "CH");
        return new Channel(id, name, shortName, group,
                "https://picserve.netplus.ch/channels/" + logoFile,
                epgId, note, noteColor, Arrays.asList(primary));
    }
}
