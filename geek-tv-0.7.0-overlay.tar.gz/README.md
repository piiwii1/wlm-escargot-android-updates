# Geek TV 0.7.0

Phase 5 — premier DVR manuel.

- applicationId conservé : `ch.piiwii.tv`
- versionCode 7 / versionName 0.7.0
- même signature Android que les versions précédentes
- direct HLS + multi-sources + diagnostics conservés
- EPG/Guide XMLTV + cache local conservés
- nouvel onglet Enregistrements
- bouton Enregistrer sur le direct
- durées : arrêt manuel, 30 min, 1 h, 2 h, fin de l'émission EPG
- service Android au premier plan pour continuer écran éteint / app en arrière-plan
- notification persistante avec action Arrêter
- enregistrement des segments HLS originaux + playlist locale, sans recompression
- support TS et fMP4/CMAF avec EXT-X-MAP
- refus explicite des playlists HLS chiffrées/protégées
- reprise de lecture locale et protection contre suppression

Limite Android 15 : un service `dataSync` est plafonné par le système à 6 h cumulées par 24 h en arrière-plan. Geek TV interrompt proprement l'enregistrement si ce plafond système est atteint.
