package ch.piiwii.remote2.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

internal object UiKit {
    const val BG = 0xFF0B111B.toInt()
    const val SURFACE = 0xFF141D2A.toInt()
    const val SURFACE_ALT = 0xFF1B2635.toInt()
    const val TEXT = 0xFFF4F7FB.toInt()
    const val TEXT_SECONDARY = 0xFFAAB7C8.toInt()
    const val ACCENT = 0xFF58A6D8.toInt()
    const val OFFLINE = 0xFFD06969.toInt()

    fun dp(context: Context, value: Int): Int = (value * context.resources.displayMetrics.density).toInt()

    fun rounded(color: Int, radiusDp: Int, context: Context): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(context, radiusDp).toFloat()
    }

    fun title(context: Context, text: String, size: Float = 25f) = TextView(context).apply {
        this.text = text
        setTextColor(TEXT)
        textSize = size
        setTypeface(typeface, Typeface.BOLD)
    }

    fun secondary(context: Context, text: String, size: Float = 14f) = TextView(context).apply {
        this.text = text
        setTextColor(TEXT_SECONDARY)
        textSize = size
        setLineSpacing(0f, 1.15f)
    }

    fun card(context: Context, padding: Int = 18, block: LinearLayout.() -> Unit): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(SURFACE, 18, context)
        val p = dp(context, padding)
        setPadding(p, p, p, p)
        block()
    }

    fun addGap(parent: LinearLayout, dp: Int) {
        parent.addView(View(parent.context), LinearLayout.LayoutParams(1, this.dp(parent.context, dp)))
    }

    fun lp(width: Int = ViewGroup.LayoutParams.MATCH_PARENT, height: Int = ViewGroup.LayoutParams.WRAP_CONTENT) =
        LinearLayout.LayoutParams(width, height)
}
