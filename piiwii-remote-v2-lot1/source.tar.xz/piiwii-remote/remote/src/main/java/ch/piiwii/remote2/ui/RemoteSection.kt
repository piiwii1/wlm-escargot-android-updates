package ch.piiwii.remote2.ui

enum class RemoteSection(val label: String, val glyph: String) {
    REMOTE("Télécommande", "◉"),
    NAVIGATION("Navigation", "✣"),
    TOUCHPAD("Pavé tactile", "⌁"),
    APPS("Applications", "▦")
}
