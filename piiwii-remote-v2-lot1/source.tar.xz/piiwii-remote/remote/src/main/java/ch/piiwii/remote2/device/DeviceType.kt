package ch.piiwii.remote2.device

enum class DeviceType(val label: String) {
    WINDOWS_PC("PC Windows"),
    ANDROID_TV("Android TV")
}
