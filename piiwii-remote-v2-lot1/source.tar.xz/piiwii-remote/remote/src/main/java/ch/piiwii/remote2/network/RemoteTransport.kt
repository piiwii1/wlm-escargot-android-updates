package ch.piiwii.remote2.network

import ch.piiwii.remote2.device.RemoteDevice
import ch.piiwii.remote2.protocol.ProtocolMessage

interface RemoteTransport {
    suspend fun send(device: RemoteDevice, message: ProtocolMessage): Result<Unit>
}
