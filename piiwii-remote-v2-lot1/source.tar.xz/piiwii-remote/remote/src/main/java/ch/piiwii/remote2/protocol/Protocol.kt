package ch.piiwii.remote2.protocol

import java.nio.charset.StandardCharsets
import java.util.Base64
import java.util.UUID

object Protocol {
    const val VERSION = "PIIWII_REMOTE/1"
}

data class ProtocolMessage(
    val requestId: String = UUID.randomUUID().toString(),
    val command: RemoteCommand,
    val payload: String = ""
)

object ProtocolCodec {
    fun encode(message: ProtocolMessage): ByteArray {
        val payload64 = Base64.getEncoder().encodeToString(message.payload.toByteArray(StandardCharsets.UTF_8))
        return "${Protocol.VERSION}|${message.requestId}|${message.command.name}|$payload64"
            .toByteArray(StandardCharsets.UTF_8)
    }

    fun decode(bytes: ByteArray): ProtocolMessage {
        val raw = bytes.toString(StandardCharsets.UTF_8)
        val parts = raw.split('|', limit = 4)
        require(parts.size == 4) { "Malformed PiiWii Remote frame" }
        require(parts[0] == Protocol.VERSION) { "Unsupported protocol version" }
        val payload = String(Base64.getDecoder().decode(parts[3]), StandardCharsets.UTF_8)
        return ProtocolMessage(
            requestId = parts[1],
            command = RemoteCommand.valueOf(parts[2]),
            payload = payload
        )
    }
}
