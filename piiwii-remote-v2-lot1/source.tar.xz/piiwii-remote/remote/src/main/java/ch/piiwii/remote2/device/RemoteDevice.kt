package ch.piiwii.remote2.device

data class RemoteDevice(
    val id: String,
    val name: String,
    val type: DeviceType,
    val host: String,
    val port: Int,
    val favorite: Boolean = false,
    val lastUsedAt: Long = 0L
)
