package ch.piiwii.remote2.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import ch.piiwii.remote2.device.DeviceType
import ch.piiwii.remote2.device.RemoteDevice
import ch.piiwii.remote2.device.SharedPreferencesDeviceRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = SharedPreferencesDeviceRepository(application)

    private val _section = MutableStateFlow(RemoteSection.REMOTE)
    val section: StateFlow<RemoteSection> = _section

    private val _devices = MutableStateFlow(repository.all())
    val devices: StateFlow<List<RemoteDevice>> = _devices

    private val _selected = MutableStateFlow(repository.find(repository.selectedId()))
    val selected: StateFlow<RemoteDevice?> = _selected

    fun chooseSection(section: RemoteSection) { _section.value = section }

    fun addDevice(name: String, type: DeviceType, host: String, port: Int): RemoteDevice {
        val device = repository.create(name, type, host, port)
        repository.select(device.id)
        refresh()
        return device
    }

    fun selectDevice(id: String) {
        repository.select(id)
        refresh()
    }

    fun removeDevice(id: String) {
        repository.remove(id)
        refresh()
    }

    private fun refresh() {
        _devices.value = repository.all()
        _selected.value = repository.find(repository.selectedId())
    }
}
