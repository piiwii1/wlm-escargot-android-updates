package ch.piiwii.remote2.ui.screens

import android.content.Context
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import ch.piiwii.remote2.device.RemoteDevice
import ch.piiwii.remote2.ui.RemoteSection
import ch.piiwii.remote2.ui.UiKit

object SectionScreenFactory {
    fun create(context: Context, section: RemoteSection, device: RemoteDevice?): View {
        return when (section) {
            RemoteSection.REMOTE -> remote(context, device)
            RemoteSection.NAVIGATION -> navigation(context, device)
            RemoteSection.TOUCHPAD -> touchpad(context, device)
            RemoteSection.APPS -> apps(context, device)
        }
    }

    private fun container(context: Context, title: String): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        val p = UiKit.dp(context, 20)
        setPadding(p, p, p, p)
        addView(UiKit.title(context, title))
        UiKit.addGap(this, 18)
    }

    private fun targetText(device: RemoteDevice?): String = device?.let {
        "Cible : ${it.name} · ${it.type.label} · ${it.host}:${it.port}"
    } ?: "Aucun appareil configuré. Touchez le nom de l’appareil en haut pour en ajouter un."

    private fun remote(context: Context, device: RemoteDevice?): View = container(context, "Télécommande").apply {
        addView(UiKit.card(context) {
            addView(label(context, "Fondation multimédia"))
            UiKit.addGap(this, 7)
            addView(UiKit.secondary(context, targetText(device)))
            UiKit.addGap(this, 12)
            addView(UiKit.secondary(context, "Les boutons média ne sont volontairement pas affichés dans ce premier lot : aucun contrôle n’est présenté comme fonctionnel avant l’arrivée de l’agent/récepteur."))
        })
    }

    private fun navigation(context: Context, device: RemoteDevice?): View = container(context, "Navigation").apply {
        addView(UiKit.card(context) {
            addView(label(context, "Croix directionnelle — structure prête"))
            UiKit.addGap(this, 12)
            addView(dpadPreview(context))
            UiKit.addGap(this, 12)
            addView(UiKit.secondary(context, "Aperçu désactivé dans le Lot 1. ${targetText(device)}"))
        })
    }

    private fun touchpad(context: Context, device: RemoteDevice?): View = container(context, "Pavé tactile").apply {
        addView(UiKit.card(context, 14) {
            minimumHeight = UiKit.dp(context, 310)
            gravity = Gravity.CENTER
            addView(TextView(context).apply {
                text = "⌁"
                textSize = 54f
                gravity = Gravity.CENTER
                setTextColor(UiKit.ACCENT)
            })
            addView(label(context, "Zone tactile"))
            UiKit.addGap(this, 8)
            addView(UiKit.secondary(context, "Interface réservée au Lot 4. Aucun faux curseur et aucun clic réseau ne sont émis dans cette alpha de fondation.").apply { gravity = Gravity.CENTER })
        })
    }

    private fun apps(context: Context, device: RemoteDevice?): View = container(context, "Applications").apply {
        addView(UiKit.card(context) {
            addView(label(context, "Aucune application affichée pour l’instant"))
            UiKit.addGap(this, 8)
            addView(UiKit.secondary(context, "La détection réelle et le lancement d’applications seront ajoutés au Lot 6. L’écran est volontairement vide plutôt que d’afficher de faux raccourcis."))
            UiKit.addGap(this, 12)
            addView(UiKit.secondary(context, targetText(device)))
        })
    }

    private fun label(context: Context, text: String) = TextView(context).apply {
        this.text = text
        textSize = 17f
        setTextColor(UiKit.TEXT)
        setTypeface(typeface, Typeface.BOLD)
    }

    private fun dpadPreview(context: Context): View {
        val outer = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            alpha = 0.58f
        }
        fun key(text: String) = TextView(context).apply {
            this.text = text
            gravity = Gravity.CENTER
            textSize = if (text == "OK") 16f else 24f
            setTextColor(UiKit.TEXT)
            background = UiKit.rounded(UiKit.SURFACE_ALT, 14, context)
            layoutParams = LinearLayout.LayoutParams(UiKit.dp(context, 58), UiKit.dp(context, 50)).apply {
                setMargins(UiKit.dp(context, 5), UiKit.dp(context, 5), UiKit.dp(context, 5), UiKit.dp(context, 5))
            }
        }
        outer.addView(key("↑"))
        outer.addView(LinearLayout(context).apply {
            gravity = Gravity.CENTER
            addView(key("←")); addView(key("OK")); addView(key("→"))
        })
        outer.addView(key("↓"))
        return outer
    }
}
