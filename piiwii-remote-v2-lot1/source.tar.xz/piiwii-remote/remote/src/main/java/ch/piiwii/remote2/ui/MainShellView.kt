package ch.piiwii.remote2.ui

import android.content.Context
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import ch.piiwii.remote2.device.RemoteDevice
import ch.piiwii.remote2.ui.screens.SectionScreenFactory

class MainShellView(context: Context) : LinearLayout(context) {
    private val deviceName = TextView(context)
    private val deviceMeta = TextView(context)
    private val content = FrameLayout(context)
    private val navButtons = linkedMapOf<RemoteSection, LinearLayout>()
    private var deviceClick: (() -> Unit)? = null
    private var settingsClick: (() -> Unit)? = null
    private var sectionClick: ((RemoteSection) -> Unit)? = null

    init {
        orientation = VERTICAL
        setBackgroundColor(UiKit.BG)
        addView(topBar(), LayoutParams(LayoutParams.MATCH_PARENT, UiKit.dp(context, 82)))
        addView(content, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        addView(bottomBar(), LayoutParams(LayoutParams.MATCH_PARENT, UiKit.dp(context, 72)))
    }

    fun onDeviceClick(block: () -> Unit) { deviceClick = block }
    fun onSettingsClick(block: () -> Unit) { settingsClick = block }
    fun onSectionClick(block: (RemoteSection) -> Unit) { sectionClick = block }

    fun render(section: RemoteSection, device: RemoteDevice?) {
        deviceName.text = device?.name ?: "Aucun appareil"
        deviceMeta.text = device?.let { "${it.type.label}  ·  ● Hors ligne" } ?: "Touchez pour configurer  ·  ● Hors ligne"
        content.removeAllViews()
        content.addView(SectionScreenFactory.create(context, section, device), FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        navButtons.forEach { (key, view) ->
            val active = key == section
            view.background = UiKit.rounded(if (active) UiKit.SURFACE_ALT else UiKit.BG, 14, context)
            for (i in 0 until view.childCount) {
                (view.getChildAt(i) as? TextView)?.setTextColor(if (active) UiKit.ACCENT else UiKit.TEXT_SECONDARY)
            }
        }
    }

    private fun topBar(): View = LinearLayout(context).apply {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        val p = UiKit.dp(context, 16)
        setPadding(p, UiKit.dp(context, 10), UiKit.dp(context, 10), UiKit.dp(context, 8))
        setBackgroundColor(UiKit.BG)

        val deviceBlock = LinearLayout(context).apply {
            orientation = VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            isClickable = true
            isFocusable = true
            background = UiKit.rounded(UiKit.SURFACE, 14, context)
            setPadding(UiKit.dp(context, 14), UiKit.dp(context, 9), UiKit.dp(context, 14), UiKit.dp(context, 9))
            deviceName.apply {
                setTextColor(UiKit.TEXT)
                textSize = 17f
                setTypeface(typeface, Typeface.BOLD)
            }
            deviceMeta.apply {
                setTextColor(UiKit.TEXT_SECONDARY)
                textSize = 12f
            }
            addView(deviceName)
            addView(deviceMeta)
            setOnClickListener { deviceClick?.invoke() }
        }
        addView(deviceBlock, LayoutParams(0, LayoutParams.MATCH_PARENT, 1f))

        addView(TextView(context).apply {
            text = "⚙"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(UiKit.TEXT)
            isClickable = true
            isFocusable = true
            setOnClickListener { settingsClick?.invoke() }
        }, LayoutParams(UiKit.dp(context, 56), LayoutParams.MATCH_PARENT))
    }

    private fun bottomBar(): View = LinearLayout(context).apply {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER
        setPadding(UiKit.dp(context, 8), UiKit.dp(context, 6), UiKit.dp(context, 8), UiKit.dp(context, 6))
        setBackgroundColor(UiKit.BG)
        RemoteSection.entries.forEach { section ->
            val item = LinearLayout(context).apply {
                orientation = VERTICAL
                gravity = Gravity.CENTER
                isClickable = true
                isFocusable = true
                addView(TextView(context).apply {
                    text = section.glyph
                    textSize = 21f
                    gravity = Gravity.CENTER
                })
                addView(TextView(context).apply {
                    text = section.label
                    textSize = 10f
                    gravity = Gravity.CENTER
                    maxLines = 1
                })
                setOnClickListener { sectionClick?.invoke(section) }
            }
            navButtons[section] = item
            addView(item, LayoutParams(0, LayoutParams.MATCH_PARENT, 1f).apply {
                setMargins(UiKit.dp(context, 2), 0, UiKit.dp(context, 2), 0)
            })
        }
    }
}
