package ch.piiwii.remote2.network

import ch.piiwii.remote2.device.RemoteDevice
import ch.piiwii.remote2.protocol.ProtocolCodec
import ch.piiwii.remote2.protocol.ProtocolMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

class UdpRemoteTransport : RemoteTransport {
    override suspend fun send(device: RemoteDevice, message: ProtocolMessage): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val data = ProtocolCodec.encode(message)
            DatagramSocket().use { socket ->
                val packet = DatagramPacket(data, data.size, InetAddress.getByName(device.host), device.port)
                socket.send(packet)
            }
        }
    }
}
