package ch.piiwii.remote2.device

interface DeviceRepository {
    fun all(): List<RemoteDevice>
    fun selectedId(): String?
    fun save(device: RemoteDevice)
    fun remove(id: String)
    fun select(id: String?)
    fun find(id: String?): RemoteDevice?
}
