package ch.piiwii.remote2.device

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class SharedPreferencesDeviceRepository(context: Context) : DeviceRepository {
    private val prefs = context.getSharedPreferences("piiwii_remote_devices_v2", Context.MODE_PRIVATE)

    override fun all(): List<RemoteDevice> {
        val raw = prefs.getString(KEY_DEVICES, "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)
                    add(
                        RemoteDevice(
                            id = o.getString("id"),
                            name = o.getString("name"),
                            type = DeviceType.valueOf(o.getString("type")),
                            host = o.getString("host"),
                            port = o.getInt("port"),
                            favorite = o.optBoolean("favorite", false),
                            lastUsedAt = o.optLong("lastUsedAt", 0L)
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    override fun selectedId(): String? = prefs.getString(KEY_SELECTED, null)

    override fun save(device: RemoteDevice) {
        val devices = all().toMutableList()
        val index = devices.indexOfFirst { it.id == device.id }
        if (index >= 0) devices[index] = device else devices.add(device)
        persist(devices)
    }

    fun create(name: String, type: DeviceType, host: String, port: Int): RemoteDevice {
        return RemoteDevice(
            id = UUID.randomUUID().toString(),
            name = name.trim(),
            type = type,
            host = host.trim(),
            port = port
        ).also(::save)
    }

    override fun remove(id: String) {
        persist(all().filterNot { it.id == id })
        if (selectedId() == id) select(null)
    }

    override fun select(id: String?) {
        prefs.edit().putString(KEY_SELECTED, id).apply()
    }

    override fun find(id: String?): RemoteDevice? = all().firstOrNull { it.id == id }

    private fun persist(devices: List<RemoteDevice>) {
        val array = JSONArray()
        devices.forEach { d ->
            array.put(JSONObject().apply {
                put("id", d.id)
                put("name", d.name)
                put("type", d.type.name)
                put("host", d.host)
                put("port", d.port)
                put("favorite", d.favorite)
                put("lastUsedAt", d.lastUsedAt)
            })
        }
        prefs.edit().putString(KEY_DEVICES, array.toString()).apply()
    }

    companion object {
        private const val KEY_DEVICES = "devices"
        private const val KEY_SELECTED = "selected_device_id"
        const val DEFAULT_PORT = 45821
    }
}
