package ch.piiwii.remote2.protocol

import org.junit.Assert.assertEquals
import org.junit.Test

class ProtocolCodecTest {
    @Test
    fun unicodeAndSeparatorsRoundTrip() {
        val original = ProtocolMessage(
            requestId = "test-483921",
            command = RemoteCommand.KEYBOARD_TEXT,
            payload = "Ça fonctionne | très bien 🙂"
        )
        val decoded = ProtocolCodec.decode(ProtocolCodec.encode(original))
        assertEquals(original, decoded)
    }

    @Test
    fun protocolVersionIsStable() {
        assertEquals("PIIWII_REMOTE/1", Protocol.VERSION)
    }
}
