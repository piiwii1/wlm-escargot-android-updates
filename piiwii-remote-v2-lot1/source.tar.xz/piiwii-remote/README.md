# PiiWii Remote 2 — Lot 1

Nouvelle base technique indépendante de PiiWii Remote 1.x.

## Version
- Application : PiiWii Remote (Android téléphone)
- Package : `ch.piiwii.remote2`
- versionName : `2.0.0-alpha1`
- versionCode : `20`
- Protocole : `PIIWII_REMOTE/1`

## Contenu du Lot 1
- architecture Kotlin séparée `device`, `protocol`, `network`, `ui`, `ui/screens` ;
- barre supérieure avec appareil sélectionné, type, état hors ligne et paramètres ;
- sélection/ajout persistant d'appareils avec identifiant UUID stable ;
- quatre onglets fixes : Télécommande, Navigation, Pavé tactile, Applications ;
- structure de protocole centralisée avec commandes logiques ;
- codec Base64 UTF-8 résistant aux accents, emoji et au caractère `|` ;
- transport UDP asynchrone prêt pour les lots suivants ;
- test unitaire du codec.

Les commandes média/navigation distantes ne sont volontairement pas exposées comme fonctionnelles dans ce Lot 1 : l'agent Windows et le récepteur TV arrivent dans les lots suivants.
