# PiiWii NFC 1.0.2

Application Android NFC locale, sans serveur.

## Fonctions
- Lecture du contenu NDEF et des informations techniques visibles du tag.
- Écriture NDEF : texte, URL, téléphone, e-mail et SMS.
- Copie en deux étapes du contenu NDEF d'un tag source vers un tag cible.
- Effacement NDEF.
- Historique local avec suppression volontaire.
- Diagnostic : UID visible, technologies, type NDEF, capacité, mémoire utilisée, état d’écriture et nombre d’enregistrements.
- Détection des tags formatables NDEF.
- Protection contre une copie accidentelle sur le tag source lui-même.
- Accès direct aux réglages NFC Android.

## Limites volontaires
PiiWii NFC ne contourne aucune authentification et ne clone pas l'UID matériel d'une carte. La fonction Copier reproduit uniquement le contenu NDEF réinscriptible compatible Android.

## Version
- versionName: 1.0.2
- versionCode: 3
- package: ch.piiwii.nfc
- minSdk: 24
- targetSdk: 35
