package ch.piiwii.nfc;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import android.nfc.tech.NdefFormatable;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private enum Mode { READ, WRITE, COPY_SOURCE, COPY_TARGET, ERASE }

    private NfcAdapter nfcAdapter;
    private PendingIntent pendingIntent;
    private Mode mode = Mode.READ;
    private NdefMessage copyBuffer;
    private byte[] copySourceUid;

    private TextView statusText;
    private TextView tagInfoText;
    private TextView historyText;
    private EditText payloadInput;
    private RadioButton typeUrl;
    private RadioButton typePhone;
    private RadioButton typeEmail;
    private RadioButton typeSms;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusText = findViewById(R.id.statusText);
        tagInfoText = findViewById(R.id.tagInfoText);
        historyText = findViewById(R.id.historyText);
        payloadInput = findViewById(R.id.payloadInput);
        typeUrl = findViewById(R.id.typeUrl);
        typePhone = findViewById(R.id.typePhone);
        typeEmail = findViewById(R.id.typeEmail);
        typeSms = findViewById(R.id.typeSms);
        prefs = getSharedPreferences("history", MODE_PRIVATE);

        Button readButton = findViewById(R.id.readButton);
        Button writeButton = findViewById(R.id.writeButton);
        Button copyButton = findViewById(R.id.copyButton);
        Button eraseButton = findViewById(R.id.eraseButton);
        Button nfcSettingsButton = findViewById(R.id.nfcSettingsButton);
        Button clearHistoryButton = findViewById(R.id.clearHistoryButton);

        readButton.setOnClickListener(v -> setMode(Mode.READ, "Mode lecture : approche un tag NFC."));
        writeButton.setOnClickListener(v -> prepareWrite());
        copyButton.setOnClickListener(v -> {
            copyBuffer = null;
            copySourceUid = null;
            setMode(Mode.COPY_SOURCE, "Copie étape 1/2 : approche le tag SOURCE.");
        });
        nfcSettingsButton.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_NFC_SETTINGS)));
        clearHistoryButton.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Vider l’historique ?")
                .setMessage("Les opérations enregistrées localement seront supprimées.")
                .setNegativeButton("Annuler", null)
                .setPositiveButton("Vider", (d, w) -> { prefs.edit().remove("items").apply(); renderHistory(); })
                .show());

        eraseButton.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Effacer le tag ?")
                .setMessage("Le contenu NDEF du prochain tag compatible sera effacé.")
                .setNegativeButton("Annuler", null)
                .setPositiveButton("Continuer", (d, w) -> setMode(Mode.ERASE, "Approche le tag à effacer."))
                .show());

        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (nfcAdapter == null) {
            statusText.setText("NFC non disponible sur cet appareil.");
            readButton.setEnabled(false);
            writeButton.setEnabled(false);
            copyButton.setEnabled(false);
            eraseButton.setEnabled(false);
        } else {
            Intent intent = new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE;
            pendingIntent = PendingIntent.getActivity(this, 0, intent, flags);
            if (!nfcAdapter.isEnabled()) {
                statusText.setText("Le NFC est désactivé. Active-le dans les réglages Android.");
                statusText.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_NFC_SETTINGS)));
            }
        }

        renderHistory();
    }

    private void prepareWrite() {
        String input = payloadInput.getText().toString().trim();
        if (TextUtils.isEmpty(input)) {
            Toast.makeText(this, "Entre d’abord le contenu à écrire.", Toast.LENGTH_SHORT).show();
            return;
        }
        setMode(Mode.WRITE, "Approche le tag sur lequel écrire les données.");
    }

    private void setMode(Mode newMode, String message) {
        mode = newMode;
        statusText.setText(message);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (nfcAdapter != null && nfcAdapter.isEnabled()) {
            nfcAdapter.enableForegroundDispatch(this, pendingIntent, null, null);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (nfcAdapter != null) {
            nfcAdapter.disableForegroundDispatch(this);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent == null || !NfcAdapter.ACTION_TAG_DISCOVERED.equals(intent.getAction())
                && !NfcAdapter.ACTION_TECH_DISCOVERED.equals(intent.getAction())
                && !NfcAdapter.ACTION_NDEF_DISCOVERED.equals(intent.getAction())) {
            return;
        }
        Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
        if (tag == null) return;

        renderTagInfo(tag);
        switch (mode) {
            case READ:
                readTag(tag);
                break;
            case WRITE:
                writeCurrentInput(tag);
                break;
            case COPY_SOURCE:
                loadCopySource(tag);
                break;
            case COPY_TARGET:
                writeCopyTarget(tag);
                break;
            case ERASE:
                eraseTag(tag);
                break;
        }
    }

    private void renderTagInfo(Tag tag) {
        StringBuilder sb = new StringBuilder();
        sb.append("UID visible : ").append(toHex(tag.getId())).append('\n');
        sb.append("Technologies :\n");
        for (String tech : tag.getTechList()) {
            int p = tech.lastIndexOf('.');
            sb.append(" • ").append(p >= 0 ? tech.substring(p + 1) : tech).append('\n');
        }

        Ndef ndef = Ndef.get(tag);
        if (ndef != null) {
            sb.append("NDEF : oui\n");
            sb.append("Capacité : ").append(ndef.getMaxSize()).append(" octets\n");
            sb.append("Écriture : ").append(ndef.isWritable() ? "autorisée" : "lecture seule").append('\n');
            sb.append("Type : ").append(ndef.getType()).append('\n');
            sb.append("UID longueur : ").append(tag.getId() == null ? 0 : tag.getId().length).append(" octets\n");
            try {
                ndef.connect();
                NdefMessage current = ndef.getNdefMessage();
                int used = current == null ? 0 : current.toByteArray().length;
                sb.append("Utilisé : ").append(used).append(" / ").append(ndef.getMaxSize()).append(" octets\n");
                if (current != null && current.getRecords().length > 0) {
                    sb.append("Copie contenu : 🟢 compatible NDEF");
                } else {
                    sb.append("Copie contenu : 🟠 tag vide");
                }
            } catch (Exception e) {
                sb.append("Copie contenu : 🟠 lecture à confirmer");
            } finally {
                closeQuietly(ndef);
            }
        } else {
            NdefFormatable formattable = NdefFormatable.get(tag);
            sb.append("NDEF : non détecté\n");
            if (formattable != null) {
                sb.append("Écriture : 🟠 formatage NDEF possible");
            } else {
                sb.append("Copie contenu : 🔴 non compatible NDEF standard");
            }
        }
        tagInfoText.setText(sb.toString());
    }

    private void readTag(Tag tag) {
        Ndef ndef = Ndef.get(tag);
        if (ndef == null) {
            statusText.setText("Tag lu, mais aucun contenu NDEF standard n’est disponible.");
            addHistory("Lecture", toHex(tag.getId()), "Tag non-NDEF");
            return;
        }
        try {
            ndef.connect();
            NdefMessage message = ndef.getNdefMessage();
            String decoded = decodeMessage(message);
            int recordCount = message == null ? 0 : message.getRecords().length;
            tagInfoText.append("\nEnregistrements NDEF : " + recordCount);
            tagInfoText.append("\n\nContenu :\n" + (decoded.isEmpty() ? "(vide)" : decoded));
            statusText.setText("Lecture terminée.");
            addHistory("Lecture", toHex(tag.getId()), summarize(decoded));
        } catch (Exception e) {
            statusText.setText("Erreur de lecture : " + safeMessage(e));
        } finally {
            closeQuietly(ndef);
        }
    }

    private void writeCurrentInput(Tag tag) {
        String value = payloadInput.getText().toString().trim();
        NdefMessage message;
        if (typeUrl.isChecked()) {
            message = createUriMessage(value);
        } else if (typePhone.isChecked()) {
            message = createUriMessage(normalizePhone(value));
        } else if (typeEmail.isChecked()) {
            message = createUriMessage(normalizeEmail(value));
        } else if (typeSms.isChecked()) {
            message = createUriMessage(normalizeSms(value));
        } else {
            message = createTextMessage(value);
        }
        if (writeMessage(tag, message)) {
            statusText.setText("Écriture réussie.");
            addHistory("Écriture", toHex(tag.getId()), summarize(value));
            mode = Mode.READ;
        }
    }

    private void loadCopySource(Tag tag) {
        Ndef ndef = Ndef.get(tag);
        if (ndef == null) {
            statusText.setText("Source incompatible : aucun message NDEF à copier.");
            return;
        }
        try {
            ndef.connect();
            NdefMessage message = ndef.getNdefMessage();
            if (message == null || message.getRecords().length == 0) {
                statusText.setText("Le tag source est vide.");
                return;
            }
            copyBuffer = cloneMessage(message);
            copySourceUid = tag.getId() == null ? null : tag.getId().clone();
            mode = Mode.COPY_TARGET;
            statusText.setText("Copie étape 2/2 : source mémorisée. Approche maintenant le tag CIBLE.");
            addHistory("Copie source", toHex(tag.getId()), summarize(decodeMessage(message)));
        } catch (Exception e) {
            statusText.setText("Impossible de lire la source : " + safeMessage(e));
        } finally {
            closeQuietly(ndef);
        }
    }

    private void writeCopyTarget(Tag tag) {
        if (copyBuffer == null) {
            setMode(Mode.COPY_SOURCE, "Le tampon de copie est vide. Approche à nouveau le tag SOURCE.");
            return;
        }
        if (copySourceUid != null && Arrays.equals(copySourceUid, tag.getId())) {
            statusText.setText("C'est encore le tag SOURCE. Présente un autre tag comme CIBLE.");
            return;
        }
        if (writeMessage(tag, copyBuffer)) {
            statusText.setText("Copie terminée. Le contenu NDEF a été reproduit sur la cible.");
            addHistory("Copie cible", toHex(tag.getId()), summarize(decodeMessage(copyBuffer)));
            copyBuffer = null;
            copySourceUid = null;
            mode = Mode.READ;
        }
    }

    private void eraseTag(Tag tag) {
        NdefMessage empty = new NdefMessage(new NdefRecord[]{
                new NdefRecord(NdefRecord.TNF_EMPTY, new byte[0], new byte[0], new byte[0])
        });
        if (writeMessage(tag, empty)) {
            statusText.setText("Tag effacé.");
            addHistory("Effacement", toHex(tag.getId()), "NDEF vidé");
            mode = Mode.READ;
        }
    }

    private boolean writeMessage(Tag tag, NdefMessage message) {
        int size = message.toByteArray().length;
        Ndef ndef = Ndef.get(tag);
        if (ndef != null) {
            try {
                ndef.connect();
                if (!ndef.isWritable()) {
                    statusText.setText("Ce tag est en lecture seule.");
                    return false;
                }
                if (ndef.getMaxSize() < size) {
                    statusText.setText("Données trop grandes : " + size + " octets pour une capacité de " + ndef.getMaxSize() + ".");
                    return false;
                }
                ndef.writeNdefMessage(message);
                return true;
            } catch (Exception e) {
                statusText.setText("Erreur d’écriture : " + safeMessage(e));
                return false;
            } finally {
                closeQuietly(ndef);
            }
        }

        NdefFormatable formatable = NdefFormatable.get(tag);
        if (formatable != null) {
            try {
                formatable.connect();
                formatable.format(message);
                return true;
            } catch (Exception e) {
                statusText.setText("Impossible de formater/écrire : " + safeMessage(e));
                return false;
            } finally {
                try { formatable.close(); } catch (Exception ignored) { }
            }
        }

        statusText.setText("Ce tag n’est pas inscriptible en NDEF avec Android.");
        return false;
    }

    private String normalizePhone(String value) {
        String v = value.trim();
        return v.startsWith("tel:") ? v : "tel:" + v;
    }

    private String normalizeEmail(String value) {
        String v = value.trim();
        return v.startsWith("mailto:") ? v : "mailto:" + v;
    }

    private String normalizeSms(String value) {
        String v = value.trim();
        return v.startsWith("sms:") || v.startsWith("smsto:") ? v : "sms:" + v;
    }

    private NdefMessage createTextMessage(String text) {
        byte[] lang = Locale.getDefault().getLanguage().getBytes(StandardCharsets.US_ASCII);
        byte[] body = text.getBytes(StandardCharsets.UTF_8);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(lang.length & 0x3F);
        out.write(lang, 0, lang.length);
        out.write(body, 0, body.length);
        NdefRecord record = new NdefRecord(NdefRecord.TNF_WELL_KNOWN, NdefRecord.RTD_TEXT,
                new byte[0], out.toByteArray());
        return new NdefMessage(new NdefRecord[]{record});
    }

    private NdefMessage createUriMessage(String uri) {
        String normalized = uri;
        if (!uri.matches("^[a-zA-Z][a-zA-Z0-9+.-]*:.*$")) {
            normalized = "https://" + uri;
        }
        return new NdefMessage(new NdefRecord[]{NdefRecord.createUri(normalized)});
    }

    private String decodeMessage(NdefMessage message) {
        if (message == null) return "";
        List<String> items = new ArrayList<>();
        for (NdefRecord r : message.getRecords()) {
            String v = decodeRecord(r);
            if (!TextUtils.isEmpty(v)) items.add(v);
        }
        return TextUtils.join("\n", items);
    }

    private String decodeRecord(NdefRecord r) {
        try {
            if (r.getTnf() == NdefRecord.TNF_WELL_KNOWN && Arrays.equals(r.getType(), NdefRecord.RTD_TEXT)) {
                byte[] payload = r.getPayload();
                if (payload.length == 0) return "";
                boolean utf16 = (payload[0] & 0x80) != 0;
                int langLen = payload[0] & 0x3F;
                Charset cs = utf16 ? StandardCharsets.UTF_16 : StandardCharsets.UTF_8;
                int start = 1 + langLen;
                return start <= payload.length ? "Texte : " + new String(payload, start, payload.length - start, cs) : "Texte : (illisible)";
            }
            if (r.getTnf() == NdefRecord.TNF_WELL_KNOWN && Arrays.equals(r.getType(), NdefRecord.RTD_URI)) {
                return "URL : " + r.toUri();
            }
            if (r.getTnf() == NdefRecord.TNF_MIME_MEDIA) {
                return "MIME " + new String(r.getType(), StandardCharsets.US_ASCII) + " : " + r.getPayload().length + " octets";
            }
            return "Enregistrement NDEF : TNF=" + r.getTnf() + ", type=" + new String(r.getType(), StandardCharsets.US_ASCII) + ", " + r.getPayload().length + " octets";
        } catch (Exception e) {
            return "Enregistrement NDEF non décodable (" + r.getPayload().length + " octets)";
        }
    }

    private NdefMessage cloneMessage(NdefMessage source) {
        byte[] bytes = source.toByteArray();
        try {
            return new NdefMessage(bytes);
        } catch (Exception e) {
            return source;
        }
    }

    private String toHex(byte[] data) {
        if (data == null || data.length == 0) return "—";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < data.length; i++) {
            if (i > 0) sb.append(':');
            sb.append(String.format(Locale.ROOT, "%02X", data[i] & 0xFF));
        }
        return sb.toString();
    }

    private void addHistory(String action, String uid, String details) {
        String now = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(new Date());
        String line = now + " • " + action + " • " + uid + " • " + details;
        String old = prefs.getString("items", "");
        String combined = line + (old.isEmpty() ? "" : "\n" + old);
        String[] lines = combined.split("\n");
        if (lines.length > 30) combined = TextUtils.join("\n", Arrays.copyOf(lines, 30));
        prefs.edit().putString("items", combined).apply();
        renderHistory();
    }

    private void renderHistory() {
        String h = prefs.getString("items", "");
        historyText.setText(h.isEmpty() ? "Aucun historique." : h);
    }

    private String summarize(String s) {
        if (s == null || s.trim().isEmpty()) return "(vide)";
        String one = s.replace('\n', ' ').trim();
        return one.length() > 70 ? one.substring(0, 70) + "…" : one;
    }

    private String safeMessage(Exception e) {
        String m = e.getMessage();
        return TextUtils.isEmpty(m) ? e.getClass().getSimpleName() : m;
    }

    private void closeQuietly(Ndef ndef) {
        if (ndef != null) {
            try { ndef.close(); } catch (Exception ignored) { }
        }
    }
}
