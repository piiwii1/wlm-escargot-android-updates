# PiiWii NFC: no custom rules required for 1.0.0.
