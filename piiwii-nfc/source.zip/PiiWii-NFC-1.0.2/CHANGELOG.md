# Changelog

## 1.0.2 — 2026-09-28
- Ajout de l’écriture NFC téléphone (`tel:`), e-mail (`mailto:`) et SMS (`sms:`).
- Ajout d’un bouton d’accès direct aux réglages NFC Android.
- Ajout d’un bouton pour vider l’historique avec confirmation.
- Affichage du nombre d’enregistrements NDEF lus.
- Affichage de la longueur de l’UID visible.
- Conservation du diagnostic de capacité, de la copie NDEF source/cible et de la protection contre la copie sur le tag source.

## 1.0.1 — 2026-09-28
- Ajout du diagnostic de capacité NDEF utilisée.
- Indicateur de compatibilité de copie du contenu.
- Détection des tags formatables NDEF.
- Empêche d'utiliser accidentellement le tag source comme tag cible pendant une copie.
